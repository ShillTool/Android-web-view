# Google AdMob

Find more about AdMob implemented in the project and instructions to set-up admob for your app.

## Setting up admob
* Signup for AdMob account
* Add app and fill required information
* Open `Settings > Publisher ID` copy it
* Edit `SmartWebView.java` and set `ASWV_ADMOB` to your Publisher ID
